mapboxgl.accessToken = 'pk.eyJ1IjoiNXRpdGFuNW8iLCJhIjoiY20yajNtN21mMDFmZDJpcHhkMzZmeHp0cSJ9.RfA-qtpCIqx_hXQ3vHE9vA';

const map = new mapboxgl.Map({
    container: 'map',
    style: 'mapbox://styles/mapbox/navigation-preview-day-v4',
    center: [-73.1128, -41.4692], // Coordenadas de Puerto Montt
    zoom: 12
});

const markers = [];

// Función para agregar un marcador al mapa
function addMarker(lngLat) {
    const marker = new mapboxgl.Marker({ color: 'green' })
        .setLngLat(lngLat)
        .addTo(map);
    markers.push(marker);
}

// Función para eliminar el último marcador
function removeLastMarker() {
    if (markers.length > 0) {
        const lastMarker = markers.pop();
        lastMarker.remove();
    } else {
        alert("No hay marcadores para eliminar.");
    }
}

// Manejo del formulario de inicio de sesión
document.getElementById('login-form').addEventListener('submit', function(event) {
    event.preventDefault();

    const username = document.getElementById('username').value;
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    const messageDiv = document.getElementById('message');

    if (validateEmail(email) && validatePassword(password)) {
        messageDiv.textContent = "Inicio de sesión exitoso. ¡Bienvenido!";
        messageDiv.style.color = "green";
        document.getElementById('user-name').textContent = username;
        document.querySelector('.login-container').classList.add('hidden');
        document.getElementById('account-info').classList.remove('hidden');
        document.getElementById('map').classList.remove('hidden');
        document.querySelector('.controls').classList.remove('hidden');
    } else {
        messageDiv.textContent = "Por favor, introduce un correo electrónico y contraseña válidos.";
        messageDiv.style.color = "red";
    }
});

// Función para validar el formato del correo electrónico
function validateEmail(email) {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(email);
}

// Función para validar la contraseña
function validatePassword(password) {
    return password.length >= 6; // La contraseña debe tener al menos 6 caracteres
}

// Evento para el botón de agregar marcadores
document.getElementById('add-marker').addEventListener('click', () => {
    map.once('click', (e) => {
        addMarker(e.lngLat);
    });
});

// Evento para el botón de eliminar marcadores
document.getElementById('remove-marker').addEventListener('click', () => {
    removeLastMarker();
});

// Manejo del menú lateral
document.getElementById('menu-toggle').addEventListener('click', () => {
    document.getElementById('side-menu').classList.toggle('hidden');
});

// Evento para cerrar sesión
document.getElementById('logout').addEventListener('click', () => {
    // Aquí puedes agregar la lógica para cerrar sesión
    alert('Sesión cerrada.');
});

// Evento para cerrar el menú
document.getElementById('close-menu').addEventListener('click', () => {
    document.getElementById('side-menu').classList.add('hidden');
});
// Evento para cerrar sesión
document.getElementById('logout').addEventListener('click', () => {
    // Restablecer el estado de la interfaz
    document.querySelector('.login-container').classList.remove('hidden');
    document.getElementById('account-info').classList.add('hidden');
    document.getElementById('map').classList.add('hidden');
    document.querySelector('.controls').classList.add('hidden');
    
    // Limpiar el nombre de usuario y mensaje
    document.getElementById('user-name').textContent = '';
    document.getElementById('message').textContent = '';
    
    alert('Sesión cerrada.');
});
// Obtener la ubicación del usuario
function getLocation() {
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(showPosition, showError);
    } else {
        alert("Geolocalización no es soportada por este navegador.");
    }
}
// Mostrar la posición en el mapa
function showPosition(position) {
    const userLocation = [position.coords.longitude, position.coords.latitude];

    // Verifica si la ubicación es de Santiago
    const santiagoCoords = [-70.6483, -33.4569]; // Coordenadas de Santiago
    const puertoMonttCoords = [-73.1128, -41.4692]; // Coordenadas de Puerto Montt

    const isInSantiago = (Math.abs(userLocation[0] - santiagoCoords[0]) < 1) && 
                         (Math.abs(userLocation[1] - santiagoCoords[1]) < 1);

    // Si está en Santiago, usa las coordenadas de Puerto Montt
    if (isInSantiago) {
        map.setCenter(puertoMonttCoords);
        new mapboxgl.Marker({ color: 'red' })
            .setLngLat(puertoMonttCoords)
            .addTo(map);
    } else {
        // Centrar el mapa en la ubicación del usuario
        map.setCenter(userLocation);
        
        // Agregar un marcador para la ubicación del usuario
        new mapboxgl.Marker({ color: 'red' })
            .setLngLat(userLocation)
            .addTo(map);
    }
}

// Manejar errores
function showError(error) {
    switch(error.code) {
        case error.PERMISSION_DENIED:
            alert("El usuario negó la solicitud de Geolocalización.");
            break;
        case error.POSITION_UNAVAILABLE:
            alert("La ubicación no está disponible.");
            break;
        case error.TIMEOUT:
            alert("La solicitud de Geolocalización ha caducado.");
            break;
        case error.UNKNOWN_ERROR:
            alert("Se produjo un error desconocido.");
            break;
    }
}

// Llamar a la función al cargar el mapa
map.on('load', () => {
    getLocation();
});
// Array de contenedores de basura con coordenadas y descripciones
const trashBins = [
    { coords: [-72.994694, -41.478772], description: 'Contenedores' },
    { coords: [-72.994703, -41.478756], description: 'Contenedores' },
    { coords: [-72.994730, -41.478739], description: 'Contenedores' },
   { coords: [-72.991338, -41.479016], description: 'Contenedores' },
   { coords: [-72.991238, -41.479058], description: 'Contenedores' },
   { coords: [-72.991086, -41.479073], description: 'Contenedores' },
   { coords: [-72.990352, -41.479188], description: 'Contenedores' },
   { coords: [-72.990336, -41.479203], description: 'Contenedores' },
  { coords: [-72.990961, -41.480081], description: 'Contenedores' },
  { coords: [-72.990937, -41.480073], description: 'Contenedores' },
  { coords: [-72.991251, -41.480265], description: 'Contenedores' },
  { coords: [-72.991567, -41.480447], description: 'Contenedores' },
  { coords: [-72.992290, -41.480788], description: 'Contenedores' },
  { coords: [-72.992783, -41.481123], description: 'Contenedores' },
  { coords: [-72.992776, -41.481111], description: 'Contenedores' },
  { coords: [-72.993784, -41.481566], description: 'Contenedores' },
  { coords: [-72.994218, -41.481778], description: 'Contenedores' },
  { coords: [-72.995087, -41.482283], description: 'Contenedores' },
  { coords: [-72.995866, -41.483193], description: 'Contenedores' },
  { coords: [-72.996667, -41.483539], description: 'Contenedores' },
  { coords: [-72.996677, -41.483547], description: 'Contenedores' },
  { coords: [-72.997807, -41.484101], description: 'Contenedores' },
  { coords: [-72.997860, -41.484143], description: 'Contenedores' },
  { coords: [-72.998579, -41.484735], description: 'Contenedores' },
  { coords: [-72.998578, -41.484756], description: 'Contenedores' },
  { coords: [-72.998640, -41.484814], description: 'Contenedores' },
  { coords: [-72.999243, -41.485404], description: 'Contenedores' },
];

// Función para crear un marcador personalizado
function createSmallMarker(color) {
    const el = document.createElement('div');
    el.className = 'marker'; // Asegúrate de definir esta clase en CSS
    el.style.backgroundColor = color;
    el.style.width = '20px'; // Cambia el tamaño aquí
    el.style.height = '20px'; // Cambia el tamaño aquí
    el.style.borderRadius = '50%'; // Hace que el marcador sea redondo
    el.style.boxShadow = '0 2px 10px rgba(0, 0, 0, 0.5)';
    return el;
}

// Agregar marcadores para cada contenedor
trashBins.forEach(bin => {
    const marker = new mapboxgl.Marker(createSmallMarker('blue')) // Usar el marcador pequeño
        .setLngLat(bin.coords)
        .addTo(map);
    
    // Agregar un popup al marcador
    const popup = new mapboxgl.Popup({ offset: 25 })
        .setText(bin.description);

    marker.setPopup(popup); // Asociar el popup al marcador
});
